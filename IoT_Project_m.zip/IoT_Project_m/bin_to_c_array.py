# bin_to_c_array.py

def bin_to_c_array(input_file, output_file, array_name="water_model_tflite"):
    with open(input_file, "rb") as f:
        data = f.read()

    with open(output_file, "w") as f:
        f.write(f"const unsigned char {array_name}[] = {{\n")
        for i in range(0, len(data), 12):
            line = ", ".join(f"0x{b:02x}" for b in data[i:i+12])
            f.write(f"  {line},\n")
        f.write("};\n")
        f.write(f"const unsigned int {array_name}_len = {len(data)};\n")

# Example usage:
bin_to_c_array("water_model.tflite", "model_data.h")
