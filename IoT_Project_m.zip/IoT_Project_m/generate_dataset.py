# generate_dataset.py
import csv
import random

with open("water_usage.csv", "w", newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["hour", "day", "label"])  # Header

    for _ in range(600):
        hour = random.randint(0, 23)
        day = random.randint(0, 6)

        # Logic for usage trend → label
        if hour in range(6, 9) or hour in range(18, 21):
            label = 2  # High
        elif hour in range(12, 15):
            label = 1  # Medium
        else:
            label = 0  # Low

        writer.writerow([hour, day, label])

print("✅ Dataset saved as water_usage.csv")
