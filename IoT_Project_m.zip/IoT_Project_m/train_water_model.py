import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# --- Load dataset ---
df = pd.read_csv("water_usage.csv")
X = df[["hour", "day"]].values
y = tf.keras.utils.to_categorical(df["label"], num_classes=3)

# --- Normalize ---
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# --- Split ---
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# --- Build Model ---
model = Sequential([
    Dense(32, activation='relu', input_shape=(2,)),
    Dense(16, activation='relu'),
    Dense(3, activation='softmax')
])
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# --- Train ---
model.fit(X_train, y_train, epochs=50, validation_data=(X_test, y_test), verbose=1)

# --- Accuracy ---
train_acc = model.evaluate(X_train, y_train, verbose=0)[1]
test_acc = model.evaluate(X_test, y_test, verbose=0)[1]
print(f"\n✅ Train Accuracy: {train_acc*100:.2f}%")
print(f"✅ Test Accuracy : {test_acc*100:.2f}%")

# --- Save Model + Normalizer ---
model.save("water_model.h5")
np.savez("normalization.npz", mean=scaler.mean_, scale=scaler.scale_)

# --- Convert to TFLite ---
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()
with open("water_model.tflite", "wb") as f:
    f.write(tflite_model)

print("📦 Saved: water_model.h5, water_model.tflite, normalization.npz")
